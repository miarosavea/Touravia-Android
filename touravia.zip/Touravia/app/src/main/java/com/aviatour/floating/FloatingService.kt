package com.aviatour.floating

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class FloatingService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var panel: View
    private lateinit var bubble: View
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var panelShown = false
    private var bubbleShown = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildPanel()
        buildBubble()
        showBubble() // démarre réduit : prend très peu de place
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("float", "Touravia", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "float")
            .setContentTitle("Touravia actif")
            .setContentText("Appuyez sur la bulle pour ouvrir")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun newParams(w: Int, h: Int, focusable: Boolean) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            (if (focusable) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE),
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = dp(10); y = dp(120)
        softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
    }

    /** Rend `handle` capable de déplacer la vue `target`. onTap / onLong facultatifs. */
    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(
        handle: View, target: () -> View, params: () -> WindowManager.LayoutParams,
        onTap: (() -> Unit)? = null, onLong: (() -> Unit)? = null
    ) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        val longRun = Runnable { if (!moved) onLong?.invoke() }
        handle.setOnTouchListener { _, e ->
            val p = params()
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false
                    if (onLong != null) handler.postDelayed(longRun, 800)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) { moved = true; handler.removeCallbacks(longRun) }
                    if (moved) {
                        p.x = sx + dx.toInt(); p.y = sy + dy.toInt()
                        wm.updateViewLayout(target(), p)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    if (!moved) onTap?.invoke()
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longRun)
            }
            true
        }
    }

    private fun roundBg(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun buildPanel() {
        panelParams = newParams(dp(260), dp(340), focusable = true)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(Color.WHITE, dp(12).toFloat())
            clipToOutline = true
        }

        // Barre : titre (glisser) + réduire + fermer
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#2c3e50"))
        }
        val title = TextView(this).apply {
            text = "⠿ TOURAVIA"
            setTextColor(Color.WHITE); textSize = 13f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        fun barBtn(label: String, action: () -> Unit) = TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 18f
            gravity = Gravity.CENTER
            setOnClickListener { action() }
        }
        bar.addView(title, LinearLayout.LayoutParams(0, dp(36), 1f))
        bar.addView(barBtn("—") { showBubble() }, LinearLayout.LayoutParams(dp(40), dp(36)))
        bar.addView(barBtn("✕") { stopSelf() }, LinearLayout.LayoutParams(dp(40), dp(36)))
        makeDraggable(title, { panel }, { panelParams })

        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            loadUrl("file:///android_asset/index.html")
        }

        // Poignée de redimensionnement (coin bas-droite)
        val grip = TextView(this).apply {
            text = "◢"; setTextColor(Color.parseColor("#7f8c8d")); textSize = 16f
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(0, 0, dp(6), 0)
            setBackgroundColor(Color.parseColor("#ecf0f1"))
        }
        var w0 = 0; var h0 = 0; var rx = 0f; var ry = 0f
        grip.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { w0 = panelParams.width; h0 = panelParams.height; rx = e.rawX; ry = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    val dm = resources.displayMetrics
                    panelParams.width = (w0 + (e.rawX - rx).toInt()).coerceIn(dp(200), dm.widthPixels)
                    panelParams.height = (h0 + (e.rawY - ry).toInt()).coerceIn(dp(220), dm.heightPixels)
                    wm.updateViewLayout(panel, panelParams)
                }
            }
            true
        }

        container.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        container.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        container.addView(grip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)))
        panel = container
    }

    private fun buildBubble() {
        bubbleParams = newParams(dp(52), dp(52), focusable = false)
        bubble = TextView(this).apply {
            text = "⏱"; textSize = 24f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E62C3E50"))
                setStroke(dp(2), Color.WHITE)
            }
            elevation = dp(6).toFloat()
        }
        makeDraggable(bubble, { bubble }, { bubbleParams },
            onTap = { showPanel() },
            onLong = { stopSelf() }) // appui long = fermer
    }

    private fun showPanel() {
        if (bubbleShown) { wm.removeView(bubble); bubbleShown = false }
        panelParams.x = bubbleParams.x; panelParams.y = bubbleParams.y
        if (!panelShown) { wm.addView(panel, panelParams); panelShown = true }
    }

    private fun showBubble() {
        if (panelShown) { wm.removeView(panel); panelShown = false
            bubbleParams.x = panelParams.x; bubbleParams.y = panelParams.y }
        if (!bubbleShown) { wm.addView(bubble, bubbleParams); bubbleShown = true }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (panelShown) wm.removeView(panel)
        if (bubbleShown) wm.removeView(bubble)
        super.onDestroy()
    }
}
